// This is the main entry for the HiveOS widget frontend.
// Place this file in frontend/widgets/ and register it in your app as needed.
// See info.json for widget metadata and registration info.
