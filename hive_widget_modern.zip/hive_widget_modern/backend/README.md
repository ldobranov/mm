# HiveOS Widget Backend

This folder contains the backend logic and API routes for the HiveOS widget.
- Place this folder in backend/app/widgets/hive/ or similar.
- See info.json in the root for registration and integration info.
