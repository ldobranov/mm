Hive Widget Backend Support
==========================

This folder contains the backend support for the HiveOS widget for the MM App.

Files:
- meta.json: Metadata for the widget (name, description, enabled, route)
- routes.py: FastAPI routes for widget template and metadata management
- logic.py: Python logic for widget data (example placeholder)
- template.html: Example Jinja/HTML template for widget rendering

How to use:
-----------
- Place this folder (`hive/`) inside your backend `app/widgets/` directory.
- The backend will expose endpoints for `/widgets/hive/meta`, `/widgets/hive/template`, etc.
- You can edit the template and metadata via the admin UI or API.
- Add your widget logic in `logic.py` as needed.

To package for upload:
----------------------
1. Zip the contents of this folder (not the folder itself) so the zip root contains meta.json, routes.py, logic.py, template.html, and README.md.
2. Upload the zip via the Widget Manager in the admin panel.

Security Note:
--------------
Only upload backend widget zips from trusted sources. Backend code runs on your server and can access your data and system.
